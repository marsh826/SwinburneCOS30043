const app = Vue.createApp({});
